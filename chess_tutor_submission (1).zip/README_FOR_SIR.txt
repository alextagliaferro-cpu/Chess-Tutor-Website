Chess Tutor - HSC Software Engineering Major Project

How to run:
1. Unzip the folder.
2. Open Terminal in the chess_tutor_project folder.
3. Run: python3 -m venv venv
4. Run: source venv/bin/activate
5. Run: pip install -r requirements.txt
6. Optional email setup before running the server:
   export EMAIL_HOST_USER="chess.tutor.org@gmail.com"
   export EMAIL_HOST_PASSWORD="upwwldjkxrrgpkwk"
7. Run: python3 manage.py migrate
8. Run: python3 manage.py runserver
9. Open: http://127.0.0.1:8000

Email note:
- Email verification and password reset use Gmail SMTP.
- If the school Wi-Fi blocks Gmail SMTP, emails may not send.
- If email does not work, use the existing demo account instead:
  Username: domb
  Password: TesterTester123*

Notes:
- The project is a Django web application focused on chess tutoring.
- The virtual environment is not included because it is large and machine-specific.
- The included database keeps the current demo progress/data available for marking.
- Stockfish improves bot move quality if installed on the computer.
- Email verification uses Gmail app-password settings through environment variables.
